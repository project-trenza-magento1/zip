<?php
/**
 * MageWorx
 * MageWorx SeoBase Extension
 *
 * @category   MageWorx
 * @package    MageWorx_SeoBase
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */

/**
 * This class was deprecated since SeoBase 3.18.0.
 * Now it is used only for compatibility with previous fixes of class rewrites.
 */

class MageWorx_SeoBase_Block_Page_Html_Head extends MageWorx_SeoBase_Block_Page_Html_Head_Abstract
{

}