<?php
/**
 * MageWorx
 * MageWorx SeoMarkup Extension
 * 
 * @category   MageWorx
 * @package    MageWorx_SeoMarkup
 * @copyright  Copyright (c) 2015 MageWorx (http://www.mageworx.com/)
 */



class MageWorx_SeoMarkup_Model_Richsnippet_Catalog_Product_Price_Default extends MageWorx_SeoMarkup_Model_Richsnippet_Catalog_Product_Price_Abstract
{

}